<?php

namespace Modules\Recruitment\Database\Seeders;

use Illuminate\Database\Seeder;

class RecruitmentDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
