<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\TenantServiceProvider::class,
    Nwidart\Modules\LaravelModulesServiceProvider::class,
];
