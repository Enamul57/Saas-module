<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\TenantController;
use App\Http\Middleware\IdentifyTenant;
use App\Models\Feature;
use App\Models\User;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use Spatie\Permission\Models\Role;

//checking web routes
foreach (config('tenancy.central_domains') as $domain) {
    Route::domain($domain)
        ->middleware(['web', IdentifyTenant::class]) // ensure session/auth/web middlewares apply
        ->group(function () {
            // Central routes

            Route::get('/', function () {
                return Inertia::render('Welcome', [
                    'canLogin' => Route::has('central.login'),
                    'canRegister' => Route::has('central.register'),
                    'laravelVersion' => Application::VERSION,
                    'phpVersion' => PHP_VERSION,
                ]);
            });
            Route::get('/dashboard', function () {
                return Inertia::render('Dashboard');
            })->middleware(['auth', 'verified'])->name('central.dashboard');

            Route::middleware('auth')->group(function () {
                Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
                Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
                Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

                //create tenant 
                Route::resource('company', TenantController::class);
            });
            Route::get('/tests', function () {
                // $roleNames = auth()->user()->getRoleNames();
                // $roleIds = Role::whereIn('name', $roleNames)->pluck('id');
                // $moduleRole = Role::whereIn('id', $roleIds)->with('features')->get();
                // $getModuleNames = $moduleRole->pluck('features.*.slug')->flatten();
                // $hasModule = $getModuleNames->contains('user-management');
                // $hasModule = auth()->user()->roles()->with('features')->get()->pluck('features.*.slug')->flatten()->contains('user-management');
                // dd($hasModule);
                //user permisison
                $userPermissions = User::findOrFail(2)->roles()
                    ->with(['features.permissions'])
                    ->get()
                    ->pluck('features.*.permissions.*.slug') // or id
                    ->flatten()
                    ->unique();
                dd($userPermissions->toArray());
                $getRolesId = auth()->user()->roles()->pluck('id');
                $getFeatures = Role::whereIn('id', $getRolesId)->with('features')->get()->pluck('features.*.slug')->flatten();
                $featureIds = Feature::whereIn('slug', $getFeatures)->pluck('id');
            });
            Route::get('/test', function () {
                //test permission

                dd(session('tenant_id'));
            });
            // 👇 Auth routes are central-only now
            require __DIR__ . '/auth.php';
        });
}
