<x-leave::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('leave.name') !!}</p>
</x-leave::layouts.master>
