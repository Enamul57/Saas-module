<x-usermanagement::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('usermanagement.name') !!}</p>
</x-usermanagement::layouts.master>
