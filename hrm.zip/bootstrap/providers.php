<?php

return [
    App\Providers\AppServiceProvider::class,
    // App\Providers\RouteServiceProvider::class,
    App\Providers\TenancyServiceProvider::class,
    Nwidart\Modules\LaravelModulesServiceProvider::class,
];
