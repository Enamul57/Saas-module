<?php

return [
    'name' => 'Recruitment',
];
