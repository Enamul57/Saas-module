<?php

return [
    'name' => 'PIM',
];
