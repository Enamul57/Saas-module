<x-floor::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('floor.name') !!}</p>
</x-floor::layouts.master>
