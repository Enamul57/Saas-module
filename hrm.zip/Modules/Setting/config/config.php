<?php

return [
    'name' => 'Setting',
];
