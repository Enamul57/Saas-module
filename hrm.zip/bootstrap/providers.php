<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\TenancyServiceProvider::class,
    Nwidart\Modules\LaravelModulesServiceProvider::class,
];
