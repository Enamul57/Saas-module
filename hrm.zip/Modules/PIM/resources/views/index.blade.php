<x-pim::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('pim.name') !!}</p>
</x-pim::layouts.master>
