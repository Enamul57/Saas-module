<?php

return [
    'name' => 'Time',
];
