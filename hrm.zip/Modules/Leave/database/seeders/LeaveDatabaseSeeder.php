<?php

namespace Modules\Leave\Database\Seeders;

use Illuminate\Database\Seeder;

class LeaveDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
