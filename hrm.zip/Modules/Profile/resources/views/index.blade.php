<x-profile::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('profile.name') !!}</p>
</x-profile::layouts.master>
