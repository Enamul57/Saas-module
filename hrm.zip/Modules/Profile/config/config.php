<?php

return [
    'name' => 'Profile',
];
