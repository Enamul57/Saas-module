<?php

namespace Modules\Profile\Database\Seeders;

use Illuminate\Database\Seeder;

class ProfileDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
