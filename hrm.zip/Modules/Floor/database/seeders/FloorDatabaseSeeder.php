<?php

namespace Modules\Floor\Database\Seeders;

use Illuminate\Database\Seeder;

class FloorDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
