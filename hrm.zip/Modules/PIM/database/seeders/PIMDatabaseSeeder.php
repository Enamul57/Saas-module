<?php

namespace Modules\PIM\Database\Seeders;

use Illuminate\Database\Seeder;

class PIMDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
