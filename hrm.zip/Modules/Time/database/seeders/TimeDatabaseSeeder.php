<?php

namespace Modules\Time\Database\Seeders;

use Illuminate\Database\Seeder;

class TimeDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
