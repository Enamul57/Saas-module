<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Admin\\Providers\\AdminServiceProvider',
    1 => 'Modules\\Employee\\Providers\\EmployeeServiceProvider',
    2 => 'Modules\\Floor\\Providers\\FloorServiceProvider',
    3 => 'Modules\\Leave\\Providers\\LeaveServiceProvider',
    4 => 'Modules\\PIM\\Providers\\PIMServiceProvider',
    5 => 'Modules\\Performance\\Providers\\PerformanceServiceProvider',
    6 => 'Modules\\Profile\\Providers\\ProfileServiceProvider',
    7 => 'Modules\\Recruitment\\Providers\\RecruitmentServiceProvider',
    8 => 'Modules\\Setting\\Providers\\SettingServiceProvider',
    9 => 'Modules\\Time\\Providers\\TimeServiceProvider',
    10 => 'Modules\\UserManagement\\Providers\\UserManagementServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Admin\\Providers\\AdminServiceProvider',
    1 => 'Modules\\Employee\\Providers\\EmployeeServiceProvider',
    2 => 'Modules\\Floor\\Providers\\FloorServiceProvider',
    3 => 'Modules\\Leave\\Providers\\LeaveServiceProvider',
    4 => 'Modules\\PIM\\Providers\\PIMServiceProvider',
    5 => 'Modules\\Performance\\Providers\\PerformanceServiceProvider',
    6 => 'Modules\\Profile\\Providers\\ProfileServiceProvider',
    7 => 'Modules\\Recruitment\\Providers\\RecruitmentServiceProvider',
    8 => 'Modules\\Setting\\Providers\\SettingServiceProvider',
    9 => 'Modules\\Time\\Providers\\TimeServiceProvider',
    10 => 'Modules\\UserManagement\\Providers\\UserManagementServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);