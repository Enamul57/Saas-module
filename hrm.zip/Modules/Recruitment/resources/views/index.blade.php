<x-recruitment::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('recruitment.name') !!}</p>
</x-recruitment::layouts.master>
