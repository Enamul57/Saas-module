<?php

return [
    'name' => 'Leave',
];
